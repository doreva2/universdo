# Direction graphique — Empreinte
Palette proposée, pas identité officielle vérifiée.
Canvas #F5F1E8, ink #102D46, secondary #35556B, accent #EA654B, mint #C5D8CF, white #FFFFFF.
Montserrat 900 pour titres, Montserrat 700 pour le reste. Space Mono 400 pour étapes.
Fichiers : assets/fonts/montserrat-900.woff2 ; assets/fonts/montserrat-700.woff2 ; assets/fonts/space-mono-400.woff2.
Canvas 1920×1080. Marges 110px. En-tête persistant par le parent de y60 à190.
Texte à gauche x110..960, visuel 3D à droite x1030..1780. Contenu de y240 à900. Titres 100–110px, interligne1.08 ; supports 30–34px ; labels 22–24px.
Le parent fournit le fond crème, l'en-tête, la 3D et le son. Les sous-compositions restent transparentes. Aucun faux logo officiel.
4 temps : accroche, personnalisation/création, utilisation du cachet, cible et appel à l'action.
Contrastes forts ; pas d'animation CSS ni de boucle autonome. GSAP paused, déterminisme par seek.
