#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export npm_config_cache=/tmp/hyperframes-npm-cache
export XDG_STATE_HOME=/tmp/cachet-state
mkdir -p .hyperframes/runtime
cat > .hyperframes/runtime/chromium <<'BROWSER'
#!/bin/sh
exec /usr/bin/chromium "$@" --use-gl=angle --use-angle=swiftshader --enable-unsafe-swiftshader
BROWSER
chmod +x .hyperframes/runtime/chromium
export HYPERFRAMES_BROWSER_PATH="$PWD/.hyperframes/runtime/chromium"
npm run render -- --workers 2 --no-browser-gpu --output renders/cachet-sur-mesure.mp4
