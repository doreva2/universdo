# Provenance des assets

- Modèle 3D du cachet, papiers et empreintes : création procédurale dans src/scene.js.
- Musique et effets : synthèse originale dans src/music.py ; aucun catalogue ou enregistrement tiers.
- Montserrat et Space Mono : fichiers locaux du projet précédent, licences OFL conservées.
- Bibliothèques Three.js et GSAP : versions figées, bannières et licences conservées.
- Aucun logo officiel, capture du site, photo de catalogue ou tarif utilisé.
