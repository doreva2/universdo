---
duration: 25
format: 1920x1080
mode: autonomous
music: original
captions: false
message: "Votre organisation, votre empreinte."
---

## 01-hook — 0 à 5 secondes
status: animated
asset_candidates: [procedural-3d-stamp]
Accroche « Votre identité. Votre empreinte. » ; cachet 3D flottant, orbite lente et arrivée sur une feuille.

## 02-personaliser — 5 à 11 secondes
status: animated
asset_candidates: [procedural-3d-stamp]
« Vous choisissez. Nous créons. » ; les éléments Nom, Logo et Informations apparaissent ; le cachet s'ouvre et s'assemble. Pas de faux configurateur du site.

## 03-utiliser — 11 à 18.5 secondes
status: animated
asset_candidates: [procedural-3d-stamp, procedural-document]
« Apposez. Identifiez. » ; gestes de tamponnage synchronisés au son, empreinte nette sur feuille, rapprochement caméra. Supports « Devis, courriers, dossiers… ».

## 04-cible-cta — 18.5 à 25 secondes
status: animated
asset_candidates: [procedural-3d-stamp]
« Votre cachet. Sur mesure. » ; Sociétés, ONG, Hôpitaux, Écoles ; CTA « Commandez votre cachet » ; domaine cachetsurmesure.site visible jusqu'à la fin.
