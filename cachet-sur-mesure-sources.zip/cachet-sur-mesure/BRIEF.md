---
workflow: product-launch-video
flow: automation
storyboard: no
message: "Un cachet personnalisé pour identifier votre organisation sur vos documents."
destination: web
aspect: 1920x1080
language: fr
length: 25s
audience: sociétés, ONG, hôpitaux et écoles
angle: choisissez vos informations, faites créer votre cachet, apposez votre empreinte
---

## Intent
Publicité explicative en motion design pour Cachet Sur Mesure. Le client a confirmé cette marque et écarté la partie Yuka de son texte. Carte blanche créative ; film final de 15 à 30 secondes.

## Customizations
Produit en 3D stylisée, gros plans, assemblage, personnalisation et geste de tamponnage. Musique originale et effets, sans voix off. Livraison MP4 Full HD.

## Notes
Le domaine https://cachetsurmesure.site/ a été demandé mais sa consultation échoue : CONNECT proxy 403, y compris avec escalade de lecture. Le brief utilisateur est la source de vérité. Pas de logo officiel ni de palette vérifiés : identité graphique proposée. Ne pas montrer de site ou d'application fictifs comme s'ils existaient. Pas de prix, délai, livraison, garanties ou valeur légale inventés.
