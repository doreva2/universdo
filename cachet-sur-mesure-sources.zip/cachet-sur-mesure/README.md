# Cachet Sur Mesure — Votre empreinte

Publicité explicative originale de 25 secondes, 1920×1080, 30 fps, H.264/AAC.

Quatre scènes : identité ; personnalisation du nom, logo et informations ; utilisation du cachet sur des documents ; organisations ciblées et invitation à commander.

Les modèles 3D, la musique et les effets de tamponnage sont créés pour ce projet. Aucun élément officiel de marque n’a pu être vérifié : le site fourni renvoie un blocage réseau 403. La direction graphique est une proposition, basée sur le brief utilisateur ; les textes ne promettent ni prix ni délai ni valeur juridique.

## Modifier et exporter

```sh
npm ci
npm run build
npm run audio
npm run check
npm run render -- --output renders/cachet-sur-mesure.mp4
```

En environnement Linux sans GPU matériel, `bash scripts/render-cloud.sh` choisit Chromium avec SwiftShader.

- `index.html` : assemblage et chronologie de 25 secondes.
- `compositions/frames/` : quatre scènes éditables.
- `src/scene.js` : cachet et documents 3D, caméra et mouvements déterministes.
- `src/music.py` : musique et bruitages originaux (NumPy nécessaire).
- `BRIEF.md`, `STORYBOARD.md`, `frame.md` : intention, scénario et direction graphique.

Polices Montserrat et Space Mono sous licence OFL ; Three.js MIT. Les avis se trouvent dans `assets/licenses/`. GSAP est livré avec sa bannière originale.
