"""Original upbeat 25-second soundtrack and physical stamp cues."""
import numpy as np
import wave
from pathlib import Path
RATE=48000
DURATION=25
rng=np.random.default_rng(37)
mix=np.zeros((int(RATE*DURATION),2),dtype=np.float64)
def add(signal,start,gain=.15,pan=0):
    offset=int(start*RATE)
    n=min(len(signal),len(mix)-offset)
    if offset<0 or n<=0:return
    mix[offset:offset+n,0]+=signal[:n]*gain*np.sqrt((1-pan)/2)
    mix[offset:offset+n,1]+=signal[:n]*gain*np.sqrt((1+pan)/2)
def pluck(freq,dur=.9):
    t=np.arange(int(RATE*dur))/RATE
    return (np.sin(2*np.pi*freq*t)+.28*np.sin(2*np.pi*freq*2*t)+.09*np.sin(2*np.pi*freq*3*t))*np.exp(-t*5.8)*np.minimum(t/.007,1)
beat=60/108
chords=[[50,57,62,66],[47,54,59,62],[43,50,55,59],[45,52,57,61]]
for k in range(45):
    start=k*beat
    chord=chords[(k//8)%4]
    bass=440*2**((chord[0]-12-69)/12)
    add(pluck(bass,.55),start,.20)
    if k%2==0:
        t=np.arange(int(RATE*.22))/RATE
        kick=np.sin(2*np.pi*(48*t+36*.018*(1-np.exp(-t/.018))))*np.exp(-t*24)
        add(kick,start,.31)
    for half in [0,.5]:
        t=np.arange(int(RATE*.075))/RATE
        noise=rng.normal(size=len(t));noise=np.concatenate([[0],np.diff(noise)])
        add(noise*np.exp(-t*75),start+half*beat,.018 if half==0 else .025,pan=.45)
    note=chord[(k*3)%4]+12
    add(pluck(440*2**((note-69)/12),1.0),start+beat*.25,.11,pan=-.23 if k%2 else .25)
    if k%8==0:
        dur=min(4*beat,DURATION-start)
        t=np.arange(int(RATE*dur))/RATE
        env=np.sin(np.pi*np.minimum(t/dur,1))**.65
        pad=sum(np.sin(2*np.pi*440*2**((n-69)/12)*t) for n in chord)/len(chord)
        add(pad*env,start,.095)
for when in [13.2,15.7]:
    t=np.arange(int(RATE*.19))/RATE
    impact=(rng.normal(size=len(t))*.35+np.sin(2*np.pi*110*t))*np.exp(-t*36)
    add(impact,when,.42)
    add(pluck(1174,.45),when+.1,.065,pan=.25)
t=np.arange(len(mix))/RATE
mix*=np.minimum(t/.22,1)[:,None]*np.minimum((DURATION-t)/1.0,1)[:,None]
peak=np.max(np.abs(mix));mix*=.84/max(peak,.01)
out=Path(__file__).resolve().parents[1]/'assets/empreinte-originale.wav'
with wave.open(str(out),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(RATE);f.writeframes((np.clip(mix,-1,1)*32767).astype('<i2').tobytes())
print(out)
