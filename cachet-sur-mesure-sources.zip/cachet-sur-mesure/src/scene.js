import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

window.THREE = THREE;
window.__hf = window.__hf || {};
window.__hf.buildReady = window.__hf.buildReady || {};
window.__hf.buildReady["cachet-product"] = document.fonts.ready.then(() => {
const canvas = document.getElementById('product-canvas');
const renderer = new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,preserveDrawingBuffer:true});
renderer.setSize(960,850,false);
renderer.setPixelRatio(1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.setClearColor(0x000000,0);
const scene = new THREE.Scene();
const camera = new THREE.OrthographicCamera(-5.95*960/850,5.95*960/850,5.95,-5.95,0.1,100);
scene.add(new THREE.HemisphereLight(0xffffff,0x6d7c89,2.8));
const key = new THREE.DirectionalLight(0xffffff,3.8);key.position.set(-5,10,7);scene.add(key);
const fill = new THREE.DirectionalLight(0xffd4b6,1.5);fill.position.set(6,3,-4);scene.add(fill);
const ink = new THREE.MeshStandardMaterial({color:0x102d46,roughness:0.31,metalness:0.14});
const coral = new THREE.MeshStandardMaterial({color:0xea654b,roughness:0.38,metalness:0.04});
const white = new THREE.MeshStandardMaterial({color:0xfffdf8,roughness:0.77});
const silver = new THREE.MeshStandardMaterial({color:0xc5d8cf,roughness:0.29,metalness:0.62});
const rubber = new THREE.MeshStandardMaterial({color:0x1c2030,roughness:0.91});
function rounded(w,h,d,r,mat,x=0,y=0,z=0,parent=scene){
 const m=new THREE.Mesh(new RoundedBoxGeometry(w,h,d,3,r),mat);m.position.set(x,y,z);parent.add(m);return m;
}
function texture(draw,w=1024,h=768){const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');draw(ctx,w,h);const tx=new THREE.CanvasTexture(c);tx.colorSpace=THREE.SRGBColorSpace;tx.anisotropy=4;return tx;}
const imprintTex=texture((ctx,w,h)=>{
 ctx.strokeStyle='#243F8A';ctx.fillStyle='#243F8A';ctx.lineWidth=18;
 ctx.strokeRect(30,30,w-60,h-60);ctx.lineWidth=4;ctx.strokeRect(55,55,w-110,h-110);
 ctx.save();ctx.translate(165,300);ctx.rotate(Math.PI/4);ctx.fillRect(-56,-56,112,112);ctx.restore();
 ctx.font='900 72px Montserrat';ctx.fillText('VOTRE',295,285);ctx.fillText('ORGANISATION',295,382);
 ctx.fillRect(115,480,780,5);ctx.font='700 39px Montserrat';ctx.textAlign='center';
 ctx.fillText('NOM · LOGO · INFORMATIONS',w/2,570);ctx.font='700 30px Montserrat';ctx.fillText('CACHET PERSONNALISÉ',w/2,646);
},1024,768);
const plateTex=texture((ctx,w,h)=>{
 ctx.fillStyle='#102D46';ctx.fillRect(0,0,w,h);ctx.fillStyle='#F5F1E8';
 ctx.font='900 84px Montserrat';ctx.textAlign='center';ctx.fillText('VOTRE NOM',w/2,170);
 ctx.fillStyle='#C5D8CF';ctx.font='700 34px Montserrat';ctx.fillText('VOTRE EMPREINTE',w/2,245);
},1024,320);
const stamp=new THREE.Group();scene.add(stamp);
const chassis=new THREE.Group();stamp.add(chassis);
rounded(3.5,.38,2.7,.13,ink,0,.28,0,chassis);
const rails=[];
for(const side of [-1,1]){
 rails.push(rounded(.38,2.4,2.42,.11,ink,side*1.47,1.59,0,chassis));
 rounded(.12,2.04,.13,.045,silver,side*1.20,1.5,.91,chassis);
 rounded(.12,2.04,.13,.045,silver,side*1.20,1.5,-.91,chassis);
}
const cap=new THREE.Group();stamp.add(cap);
rounded(3.52,1.04,2.8,.23,ink,0,3.03,0,cap);
rounded(3.5,.19,2.78,.07,coral,0,2.57,0,cap);
rounded(3.16,.14,2.48,.07,coral,0,3.61,0,cap);
const front=new THREE.Mesh(new THREE.PlaneGeometry(2.85,.88),new THREE.MeshBasicMaterial({map:plateTex}));front.position.set(0,3.03,1.407);cap.add(front);
const pad=new THREE.Group();stamp.add(pad);
rounded(2.98,.19,2.26,.07,silver,0,.70,0,pad);
rounded(2.84,.17,2.13,.035,rubber,0,.53,0,pad);
const padFace=new THREE.Mesh(new THREE.PlaneGeometry(2.7,1.99),new THREE.MeshBasicMaterial({map:imprintTex,transparent:true,side:THREE.DoubleSide}));padFace.rotation.x=Math.PI/2;padFace.position.y=.44;pad.add(padFace);
const shadowTex=texture((ctx,w,h)=>{const g=ctx.createRadialGradient(w/2,h/2,20,w/2,h/2,w*.45);g.addColorStop(0,'rgba(16,45,70,0.32)');g.addColorStop(.45,'rgba(16,45,70,0.12)');g.addColorStop(1,'rgba(16,45,70,0)');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);},512,512);
const shadow=new THREE.Mesh(new THREE.PlaneGeometry(7.3,6.5),new THREE.MeshBasicMaterial({map:shadowTex,transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=-.10;scene.add(shadow);
function makeDocument(title){
 const g=new THREE.Group();scene.add(g);
 rounded(6.35,.085,4.65,.045,white,0,-.047,0,g);
 const tx=texture((ctx,w,h)=>{
  ctx.fillStyle='#FFFDF8';ctx.fillRect(0,0,w,h);ctx.fillStyle='#102D46';ctx.font='900 65px Montserrat';ctx.fillText(title,90,120);
  ctx.fillStyle='#82949E';ctx.font='700 25px Montserrat';ctx.fillText('VOTRE ORGANISATION',90,177);
  ctx.fillStyle='#D3DBDF';[240,290,340,620,660].forEach((y,i)=>ctx.fillRect(90,y,i===2?660:850,8));
 },1200,900);
 const p=new THREE.Mesh(new THREE.PlaneGeometry(6.34,4.64),new THREE.MeshBasicMaterial({map:tx}));p.rotation.x=-Math.PI/2;p.position.y=.005;g.add(p);
 const inkMat=new THREE.MeshBasicMaterial({map:imprintTex,transparent:true,opacity:0,depthWrite:false});
 const mark=new THREE.Mesh(new THREE.PlaneGeometry(2.75,2.04),inkMat);mark.rotation.x=-Math.PI/2;mark.position.set(0,.011,.14);mark.rotation.z=.03;g.add(mark);
 return {g,inkMat,mark};
}
const docA=makeDocument('COURRIER');const docB=makeDocument('DOSSIER');
const accent=new THREE.Group();scene.add(accent);
for(let i=0;i<7;i++){
 const a=i*2.399963;
 const m=new THREE.Mesh(new THREE.IcosahedronGeometry(.085+(i%3)*.025,0),i%2?coral:silver);
 m.userData={angle:a,radius:3.15+(i%2)*.4};accent.add(m);
}
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v);};
const lerp=(a,b,t)=>a+(b-a)*t;
function pulse(t,c,w){const v=clamp(1-Math.abs(t-c)/w);return smooth(v);}
let last=-1;
function renderAt(t){
 t=clamp(Number(t)||0,0,25);if(Math.abs(t-last)<.000001)return;last=t;
 const explode=smooth((t-5.6)/1.1)*(1-smooth((t-9.05)/1.35));
 const isUse=t>=11&&t<18.5;
 const final=smooth((t-18.5)/1.5);
 const imprintReveal=smooth((t-16.0)/.75)*(1-smooth((t-18.5)/1.15));
 const strikeA=pulse(t,13.2,.53);const strikeB=pulse(t,15.7,.53);
 const strike=Math.max(strikeA,strikeB);
 const hover=1.05+.09*Math.sin(t*1.25);
 stamp.position.set(0,isUse?lerp(1.25,-.085,strike):lerp(hover,.58,final),.13);
 stamp.position.y+=imprintReveal*14.5;
 stamp.rotation.set(0,isUse?.03:lerp(-.18+.12*Math.sin(t*.5),-.07,final),isUse?0:.025*Math.sin(t*.7));
 cap.position.y=explode*1.55-strike*.55;
 rails.forEach((r,i)=>r.position.x=(i?1:-1)*(1.47+explode*.28));
 pad.position.y=explode*.55;
 pad.rotation.x=explode*-.60;
 const paperSwitch=smooth((t-14.35)/.75);
 docA.g.position.x=-paperSwitch*10;
 docB.g.position.set(lerp(10,0,paperSwitch),0,0);
 docA.g.visible=t<15.2;docB.g.visible=t>=14.2;
 docA.inkMat.opacity=smooth((t-13.18)/.15);
 docB.inkMat.opacity=smooth((t-15.68)/.15);
 docA.g.rotation.y=-.08;docB.g.rotation.y=-.08;
 shadow.scale.setScalar(lerp(1.0,.8,strike));shadow.material.opacity=lerp(.65,1.0,strike);
 accent.visible=t<11||t>=18.5;
 accent.children.forEach((m,i)=>{const a=m.userData.angle+t*.18;m.position.set(Math.cos(a)*m.userData.radius,1.5+Math.sin(a*1.3)*1.55,Math.sin(a)*m.userData.radius);m.rotation.set(t*.2+i,t*.3,0);m.scale.setScalar(.6+explode*.8+final*.2);});
 const useZoom=smooth((t-11)/1.0)*(1-smooth((t-17.3)/1.2));
 const yaw=.63+.045*Math.sin(t*.38);
 const elev=lerp(lerp(.70,.98,useZoom),1.24,imprintReveal);
 const targetY=lerp(lerp(1.65,.57,useZoom),.10,imprintReveal);
 camera.position.set(Math.sin(yaw)*13,Math.sin(elev)*13+targetY,Math.cos(yaw)*13);
 camera.lookAt(0,targetY,0);
 camera.zoom=1.04+useZoom*.16-final*.035+imprintReveal*.37;
 camera.updateProjectionMatrix();renderer.render(scene,camera);
}
window.cachetRender=renderAt;
window.addEventListener('hf-seek',e=>renderAt(e.detail.time));
renderAt(window.__hfThreeTime || 0);
});
